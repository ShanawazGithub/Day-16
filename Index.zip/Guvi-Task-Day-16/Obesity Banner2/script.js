// there is no javascript needed for this design only 

const design = "there is no javascript needed for this design";
console.log(design);
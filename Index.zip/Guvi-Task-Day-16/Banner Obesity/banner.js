let design = " BANNER OBESITY";
console.log(design);